create PROCEDURE ACT_PRODUCTO(v_precio productos.precio%TYPE, v_articulo productos.nomarticulo%TYPE)
AS
BEGIN
   UPDATE PRODUCTOS SET PRECIO = v_precio WHERE NOMARTICULO = v_articulo;
end;
/

